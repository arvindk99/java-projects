
public class SpecialDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SpecialSavings ss1 = new SpecialSavings(20000.00);
		
		SpecialSavings ss2 = new SpecialSavings(2000.00);
		
		ss1.calcmonthlyInterest();
		ss2.calcmonthlyInterest();

	}

}
