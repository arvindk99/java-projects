
public class Driver {
	
	public static void main(String[] args) {
		Coin quarter = new Coin();
		Coin dime = new Coin();
		Coin nickel = new Coin();
		
		Simulation s1 = new Simulation();
		s1.toss(quarter);
		s1.toss(dime);
		s1.toss(nickel);
		


	}
}
